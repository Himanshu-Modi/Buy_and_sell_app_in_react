import React from 'react';
import { Navbar, Nav, NavDropdown,Form,FormControl,Carousel,Modal,Row, } from '../node_modules/react-bootstrap';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import { Card, Image,Button, Icon, Container,Dropdown, Menu,Grid,Segment,Responsive } from 'semantic-ui-react';
import '../node_modules/bootstrap/dist/css/bootstrap.css';
import 'semantic-ui-css/semantic.min.css';
import './MainActivity.css';
import FormExampleSubcomponentControl from './FilterComponent';
import MainNavBar from './MainNavBar';


const CardExampleCard = (props) => (
  
  <Card  raised color="green" className="BooksContainer">
  <Image  className="Bookimage" src={props.type.image} wrapped-ui={false}  centered />
    <Card.Content>
      <Card.Header>{props.type.name}</Card.Header>
      <Card.Meta>
        <span className='da</div>te'>Available in  only  <h4>{props.type.price}</h4></span>
      </Card.Meta>
    
   <Link to="/bookdescription">
      <Button primary size='large' fluid  animated='vertical'>
        
      <Button.Content hidden>Shop</Button.Content>
      <Button.Content visible>
        <Icon name='shop' />
      </Button.Content>
    </Button>
    </Link>
      
    </Card.Content>
  
  </Card>
  
  
)


function ShowBooks(props){
  console.log("show Books");
  let  db=props.books;
 
  return  db.map((item)=><div> <Card.Group itemsPerRow={4} > <CardExampleCard  type={item} /> </Card.Group> </div> );
} 

function MainPage(props){
 return (
    <div>
        <div>
          <MainNavBar></MainNavBar>
        </div>

   
<div className="FilterClass">
<FormExampleSubcomponentControl></FormExampleSubcomponentControl>
  </div>
  
    <div> 
<ShowBooks books={props.books}></ShowBooks>   
</div>

         
    </div>
    
    )
}


export default MainPage;
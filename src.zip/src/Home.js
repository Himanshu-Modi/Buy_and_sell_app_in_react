import React from 'react';
import { Navbar, Nav, NavDropdown,Form,FormControl,Button,ButtonGroup,Carousel,Modal,Row , Col} from '../node_modules/react-bootstrap';
import '../node_modules/bootstrap/dist/css/bootstrap.css';
import CarouselCaption from 'react-bootstrap/CarouselCaption';
import {  Link } from "react-router-dom";

class MyVerticallyCenteredModal extends React.Component {
  render() {
    return (
      <Modal
        {...this.props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >

        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Login
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Form>
  <Form.Group controlId="formBasicEmail">
    <Form.Label>Email address</Form.Label>
    <Form.Control type="email" placeholder="Enter email" />
    <Form.Text className="text-muted">
      We'll never share your email with anyone else.
    </Form.Text>
  </Form.Group>

  <Form.Group controlId="formBasicPassword">
    <Form.Label>Password</Form.Label>
    <Form.Control type="password" placeholder="Password" />
  </Form.Group>
  <Link to="/books/all">
  <Button variant="primary" type="submit">
  
    Submit
   
  </Button>
  </Link>
</Form>
        </Modal.Body>
        
      </Modal>
    );
  }
  
}
class MyVerticallyCenteredModal2 extends React.Component {
  render() {
    return (
      <Modal
        {...this.props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >

        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            Sign Up
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Form>
    <Form.Group controlId="formBasicEmail">
  <Form.Label>First Name</Form.Label>
  <Row>
    <Col>
      <Form.Control placeholder="First name" />
    </Col>
    <Col>
      <Form.Control placeholder="Last name" />
    </Col>
  </Row>
  </Form.Group>
  <Form.Group controlId="formBasicEmail">
    <Form.Label>Email address</Form.Label>
    <Form.Control type="email" placeholder="Enter email" />
  </Form.Group>

  <Form.Group controlId="formBasicPassword">
    <Form.Label>Password</Form.Label>
    <Form.Control type="password" placeholder="Password" />
  </Form.Group>
  <Form.Group controlId="formBasicPassword">
    <Form.Label> Confirm Password</Form.Label>
    <Form.Control type="password" placeholder=" Confirm Password" />
  </Form.Group>
 
  <Button variant="primary" type="submit">
    Submit
  </Button>
</Form>
        </Modal.Body>
        
      </Modal>
    );
  }
  
}

class Home extends React.Component {

  constructor(...args){
    super(...args)
    this.state={modelShow1:false};
    this.state={modelShow2:false};

    }
    render(){
      let modalClose1 = () => this.setState({ modalShow1: false });
      let modalClose2 = () => this.setState({ modalShow2: false });
  return(
    <div>
    <Navbar bg="dark" variant="dark">
     <Navbar.Brand href="#home">
      <img
        alt=""
        src="https://upload.wikimedia.org/wikipedia/commons/4/42/OLX_New_Logo.png"
        width="65"
        height="40"
        className="d-inline-block align-top"
      />
     {'Mini Olx'}
    </Navbar.Brand>
    <Nav className="ml-auto">
    <ButtonGroup className="mr-3" aria-label="Second group">
    <Button
          variant="success"
          onClick={() => this.setState({ modalShow1: true })}
        >
         
          Login 
       

        </Button>

        <MyVerticallyCenteredModal
          show={this.state.modalShow1}
          onHide={modalClose1}
        />
   
  </ButtonGroup>
   
  <Button 
          variant="info"
          onClick={() => this.setState({ modalShow2: true })}
        >
          Sign Up
        </Button>

        <MyVerticallyCenteredModal2
          show={this.state.modalShow2}
          onHide={modalClose2}
        />
    
      
    </Nav>
  </Navbar>
  <Carousel>
  <Carousel.Item>
    <img
      className="d-block w-100"
      height="500"
      alt="First slide"
      src="https://www.rd.com/wp-content/uploads/2017/11/How-Much-Does-a-Book-Need-to-Sell-to-Be-a-Bestseller-509582812-Billion-Photos-760x506.jpg"
    />
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100"
      alt="Second slide"
      height="500"
      src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRE9n5FIWqInlAli85tZhI3Q_LDhXgnEqSjbQOutt8JTO_-IZpi"
    
    />
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100"
      alt="Third slide"
      height="500"
      src="https://images-eu.ssl-images-amazon.com/images/G/31/img19/books/042019/XCM_Manual1168081_1500x300_1_1555490143.jpg"
    />

  </Carousel.Item>
</Carousel>


  </div>

  );
  }
}

export default Home;

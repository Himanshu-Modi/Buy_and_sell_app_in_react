import React from 'react';
import './sellitem.css';
import { Navbar, Nav, NavDropdown,Form,FormControl,ButtonGroup,Carousel,Modal,Row , Col,Card,Container } from '../node_modules/react-bootstrap';
import { Dropdown, Button, Icon,Image } from 'semantic-ui-react';
import 'semantic-ui-css/semantic.min.css';
import MainNavBar from './MainNavBar';

class SellBook extends React.Component{
 
  constructor(...args){
    super(...args)
  }
  
  
  selecter(){
    const options = [
      { key: 1, text: 'IT', value: 1 },
      { key: 2, text: 'CS', value: 2 },
      { key: 3, text: 'Ec', value: 3 },
      { key: 4, text: 'EE', value: 4 },
      { key: 5, text: 'CV', value: 5 },
    ]
    
    return(<Dropdown   clearable options={options} selection />);
    
  }
  selecter1(){
    const options = [
      
      { key: 1, text: 'First', value: 1 },
      { key: 2, text: 'Second', value: 2 },
      { key: 3, text: 'Third', value: 3 },
      { key: 4, text: 'Fourth', value: 4 },
      { key: 5, text: 'Fiveth', value: 5 },
      { key: 6, text: 'Sixth', value: 6 },
      { key: 7, text: 'Seventh', value: 7 },
      { key: 8, text: 'Eighth', value: 8 },
      
    ]
    
    return(<Dropdown   clearable options={options} selection />);
    
  }
  
  render(){
  return (
    <div>
      <div><MainNavBar> </MainNavBar>
        </div>
     
  <form className="container center_div border ">
  <Container className="profileimage" align="right">
    <Row>
    
      <Col xs={6} md={4}>
        <Image src="https://s4.scoopwhoop.com/anj/787440660.jpg" rounded  className="img1"/>
      </Col>
      </Row>
  </Container>
  <br/>
  <div className="uploade  pull-center container center_div">
  <Button icon labelPosition='left'>
        <Icon name='upload' />
        uploade
      </Button>
      </div>
  <br/>
  <br/>
  <div className="">
    <h1>Branch</h1>
    {this.selecter()}
    </div>
    <br/>
    <br/>
    <div className="" >
    <h1>Semester</h1>
    {this.selecter1()}
    </div>
    <br/>
    <br/>
    <div>
    <h1>Book Name</h1>
    <input type="text" placeholder="Book Name"  className="bookname" />
  
    </div>
    <br/>
    <br/>
    <div >
    
    <input type="text" placeholder="MRP"  className="mrp" />
    
    <input type="text" placeholder="Price"  className="price" />
    </div>
    <br/>
    <br/>
    <div className="container center_div">
      <Button positive>Submit</Button>
    </div>
    </form>
  </div>
  );
  }
  
  }
  export default SellBook;
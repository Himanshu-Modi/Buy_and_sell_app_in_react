import React from 'react';
import logo from './logo.svg';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import './App.css';
import Home from './Home';
import MainPage from "./MainActivity";
import SellBook from './SellBook';
import  Accountdetails from './AccountDetails';
import Bookdescription from './bookdescription';
import axios from '../node_modules/axios';


class App extends React.Component{
  constructor(props){
    super(props)
     this.state= {}
     this.state.db = {
     books:[]
 
    }
  }
  componentDidMount(){
    axios.get('http://5cfe5a23ca949b00148d3ff2.mockapi.io/products')
    .then((res)=>{
      
    let db = this.state.db;
    db.books = res.data;
      this.setState({
         db:db
      })
    })

}
 
  render(){
    return (<div>
       <Router>
          <Route path="/" exact component={Home} />
          <Route path="/books/all" exact render={()=><MainPage books={this.state.db.books}></MainPage>} />
          <Route path="/sellbook" component={SellBook} />
          <Route path="/accountdetails" component={Accountdetails} />
          <Route path="/bookdescription" component={Bookdescription} />
       </Router>
       </div>
       );
  }
 
 

}
export default App;

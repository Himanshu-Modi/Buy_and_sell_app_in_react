import React from 'react';
import logo from './logo.svg';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import './App.css';
import Home from './Home';
import Hello from "./MainActivity";
import MainNavBar from './MainNavBar';
import './Bookdescription.css';
import { Navbar,Image,Container, Nav, NavDropdown,Form,FormControl,ButtonGroup,Carousel,Modal,Row , Col,Card } from '../node_modules/react-bootstrap';
import { Dropdown, Button, Icon,Input,Label,Header,TextArea } from 'semantic-ui-react';
import 'semantic-ui-css/semantic.min.css';

class Bookdescription extends React.Component{


constructor(...args){
  super(...args)
}


selecter(){
  const options = [
    { key: 1, text: 'IT', value: 1 },
    { key: 2, text: 'CS', value: 2 },
    { key: 3, text: 'Ec', value: 3 },
    { key: 4, text: 'EE', value: 4 },
    { key: 5, text: 'CV', value: 5 },
  ]
  
  return(<Dropdown   clearable options={options} selection />);
  
}
selecter1(){
  const options = [
    
    { key: 1, text: 'First', value: 1 },
    { key: 2, text: 'Second', value: 2 },
    { key: 3, text: 'Third', value: 3 },
    { key: 4, text: 'Fourth', value: 4 },
    { key: 5, text: 'Fiveth', value: 5 },
    { key: 6, text: 'Sixth', value: 6 },
    { key: 7, text: 'Seventh', value: 7 },
    { key: 8, text: 'Eighth', value: 8 },
    
  ]
  
  return(<Dropdown   clearable options={options} selection />);
  
}

render(){
return (
  <div>
      <div>
      <MainNavBar />
      </div>


<body className="pt-3">
<form className="container center_div form border border-secondary">
<Container className="profileimage" align="right">
  <Row>
  
    <Col xs={6} md={4}>
      <Image src="https://www.drawingnow.com/file/videos/steps/119657/how-to-draw-an-open-book-step-7.jpg" rounded  className="img1"/>
    </Col>
    <Col xs={1} md={2}>
    <Label as='a' color='grey' tag className="label">
      Branch:
    </Label>
    <Icon name='address book'/>
    <Header as='h3'>CS</Header>
    </Col>
    </Row>
    <br/>
    <Row>
    <Col xs={1} md={2}>
    <Label as='a' color='green' tag className="label"> SEM:</Label>
    <Icon name='address book outline'/>
    <Header as='h3'>sixth</Header>
    </Col>
    
    
    <Col xs={1} md={2}>
    <Label as='a' color='blue' tag className="label">BookName:</Label>
    <Icon name='address book'/>
    <Header as='h3'>Operating</Header>
    </Col>
    </Row>
    <Row>
   
    <Col xs={1} md={9}>
    <Label as='a' color='blue' tag className="label">PersonInfo:</Label>
  
    <Icon name='info circle'/>
    <TextArea  value="bansal" />
    </Col>
    
    </Row>
    
</Container>

<Row>
<Label as='a' color='teal' tag>
      MRP:
    </Label>
    <Icon name='rupee sign' />
    <Header as='h3'>250</Header>
    
<Label as='a' color='teal' tag>
      Price:
    </Label>
    <Icon name='rupee sign' className="row" />
    <Header as='h3'>125</Header>
    </Row>
    <Button positive toggle={true} className="interasted" >You are Interasted/Buy</Button>
   
  </form>
  </body>
</div>
);
}

}
export default Bookdescription;
